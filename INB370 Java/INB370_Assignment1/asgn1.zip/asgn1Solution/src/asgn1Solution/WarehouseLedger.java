package asgn1Solution;
import java.util.ArrayList;

/**
 * @author Dominic
 */

public class WarehouseLedger implements Ledger {
	
	private int currentStock;
	private int cashReserve;
	private int theWholesaleCostPerItem;
	private int theRetailPricePerItem;
	private int theDeliveryCharge;
	private int currentDay = 1;
	
    private ArrayList<Integer> cashBalanceRecords = new ArrayList<Integer>();
    private ArrayList<Integer> stockRecords = new ArrayList<Integer>();	


	
	public WarehouseLedger(int initialStock, int initialCash, int wholesaleCostPerItem,
			int retailPricePerItem, int deliveryCharge) {
		currentStock = initialStock;
		cashReserve = initialCash;
		theWholesaleCostPerItem = wholesaleCostPerItem; 
		theRetailPricePerItem = retailPricePerItem;
		theDeliveryCharge = deliveryCharge;
		
		cashBalanceRecords.add(initialCash);
	}

	/* (non-Javadoc)
	 * @see asgn1Solution.Ledger#buyItems(java.lang.Integer)
	 */
	public void buyItems(Integer required) throws WarehouseException {
		
		if (required < 0)
		{
			throw new WarehouseException("The number of items to purchase cannot be negative.");
		}
		else
		{
			int totalCost = (required * this.theWholesaleCostPerItem) + this.theDeliveryCharge;
			
			this.currentStock += required;
			this.cashReserve -= totalCost;
		}
		
	}

	/* (non-Javadoc)
	 * @see asgn1Solution.Ledger#cashAvailable()
	 */
	public Integer cashAvailable() {
		return this.cashReserve;
	}

	/* (non-Javadoc)
	 * @see asgn1Solution.Ledger#cashAvailable(java.lang.Integer)
	 */
	public Integer cashAvailable(Integer day) throws WarehouseException {
		if (day == this.currentDay())
		{
			return this.cashReserve;
		}
		else if ((day > this.currentDay()) || (day < 1))
		{
			throw new WarehouseException("The requested day cannot be greater then the current day, or before the warehouse opened.");
		}
		
		else
		{
			return this.cashBalanceRecords.get(day-1);
		}
	}

	/* (non-Javadoc)
	 * @see asgn1Solution.Ledger#currentDay()
	 */
	public Integer currentDay() {
		return this.currentDay;
	}

	/* (non-Javadoc)
	 * @see asgn1Solution.Ledger#inStock()
	 */
	public Integer inStock() {
		return this.currentStock;
	}

	/* (non-Javadoc)
	 * @see asgn1Solution.Ledger#inStock(java.lang.Integer)
	 */
	public Integer inStock(Integer day) throws WarehouseException {
		if (day == this.currentDay())
		{
			return this.currentStock;
		}
		else if ((day > this.currentDay()) || (day < 1))
		{
			throw new WarehouseException("The requested day cannot be greater then the current day, or before the warehouse opened.");
		}
		else
		{
			return this.stockRecords.get(day - 1);
		}
	}

	/* (non-Javadoc)
	 * @see asgn1Solution.Ledger#nextDay()
	 */
	public void nextDay() {
		
		this.cashBalanceRecords.add(this.cashAvailable());
		this.stockRecords.add(this.inStock());
		currentDay += 1;
	}

	/* (non-Javadoc)
	 * @see asgn1Solution.Ledger#sellItems(java.lang.Integer)
	 */
	public boolean sellItems(Integer requested) throws WarehouseException {
		if (requested < 0)
			
		{	
			throw new WarehouseException("The number of items to be sold cannot be negative.");
		}
		else
		{
			//if order cannot be filled because there isn't enough stock
			if(requested > this.currentStock)
			{
				cashReserve += (this.currentStock * this.theRetailPricePerItem);
				this.currentStock = 0;
				return false;
			}
			
			else
			{
				cashReserve += (requested * this.theRetailPricePerItem);
				this.currentStock -= requested;
				return true;
			}
		}
	}
	
	
	/* (non-Javadoc)
	 * @see asgn1Solution.Ledger#toString(java.lang.String)
	 */
	public String toString()
	{
		return "Day " + this.currentDay + ": Cash reserve = $" + this.cashReserve + "; Items in stock = " + this.inStock() +"\n" ;
	}

}
