package asgn1Solution;

/**
 * @author Dominic Bou-Samra n6869378
 */

public class WarehouseTransactions implements Transactions {
	
	private final int totalCapacity;
	private int theJobDuration;
	private boolean lastOrder = true;
	WarehouseLedger theLedger;    
    
	public WarehouseTransactions(int warehouseCapacity, int jobDuration, WarehouseLedger ledger) {
		totalCapacity = warehouseCapacity;
		theJobDuration = jobDuration;
		theLedger = ledger;
	}

	public boolean insolvent() {
		if (theLedger.cashAvailable() < 0)
		{ 
			return true;
		}
		else
		{
			return false;
		}
	}

	public boolean jobDone() {
		if (theLedger.currentDay() > this.theJobDuration)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public boolean orderUnfulfilled() {
		if (lastOrder)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	public void restockAndSellStock(Integer todaysOrder) throws WarehouseException  {
		if (todaysOrder < 0)
		{
			//I assume we are required to throw an exception in EACH method, 
			//even if they will be thrown by a called method anyway
			throw new WarehouseException("The order for today cannot be negative.");
		}
		else
		{
			theLedger.buyItems(totalCapacity - theLedger.inStock());
			this.sellStock(todaysOrder);
		}
	}

	public void sellStock(Integer todaysOrder) throws WarehouseException {
		
		if (todaysOrder < 0)
		{
			throw new WarehouseException("The order for today cannot be negative.");
		}
		else
		{
			if (theLedger.sellItems(todaysOrder))
			{
				lastOrder = true;
			}
			else
			{
				lastOrder = false;
			}
			theLedger.nextDay();
		}

	}

}
