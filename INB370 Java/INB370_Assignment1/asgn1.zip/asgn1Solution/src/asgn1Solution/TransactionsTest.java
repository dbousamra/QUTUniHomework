package asgn1Solution;
import org.junit.*;
import static org.junit.Assert.*;

/**
 * @author Dominic Bou-Samra n6869378
 */

public class TransactionsTest {

	private WarehouseLedger ledger;
	private WarehouseTransactions transaction;
	
	@Before
	public void setUp()
	{
		ledger = new WarehouseLedger(20, 80, 5, 8, 50);
		//capacity/initial stock = 20, initial cash = 80, wholesale per box = 5, 
		//retail per box = 8, delivery charge = 50
		
		transaction = new WarehouseTransactions(20, 7, ledger);
		//capacity = 20, jobduration = 7, ledger = ledger above
	}
	
	@Test
	/* Normal case - default values when transaction is constructed - should return false*/
	public void insolventDefault()
	{
		assertFalse(transaction.insolvent());
	}
	
	@Test
	/* Normal case - after buying some items, but not negative - should return false */
	public void insolventBuyingSomeItems() throws WarehouseException
	{
		ledger.buyItems(1);
		assertFalse(transaction.insolvent());
		}
	
	@Test
	/* Normal case - negative cash reserve - should return true*/
	public void insolventNegativeCashReserve() throws WarehouseException
	{
		//for the sake of pushing the cashreserve into negative values, I can use this method
		//however the restockAndSellStock method won't allow the buying of MORE then the warehouse can hold
		ledger.buyItems(30);
		assertTrue(transaction.insolvent());
	}
	
	@Test
	/* Border case - cash reserve equals zero - should return false */
	public void insolventCashReserveOfZero() throws WarehouseException
	{
		ledger.buyItems(6);
		assertFalse(transaction.insolvent());
	}
	
	@Test
	/* Normal case - default values when transaction is constructed - should return false */
	public void orderUnfulfilledDefault()
	{
		assertFalse(transaction.orderUnfulfilled());
	}
	
	@Test
	/* Normal case - after completing 1 order using the sellStock method - should return false */
	public void orderUnfulfilledAfterBuying() throws WarehouseException
	{
		transaction.sellStock(12);
		assertFalse(transaction.orderUnfulfilled());
	}
	
	@Test
	/* Normal case - after completing orders that cannot be filled because there isn't enough stock using the sellStock method */
	public void orderUnfulfilledAfterBuyingTooMuch() throws WarehouseException
	{
		transaction.sellStock(30);
		assertTrue(transaction.orderUnfulfilled());
	}
	
	@Test
	/* Normal case - default constructed values - should return false */
	public void jobDoneDefaultValues()
	{
		assertFalse(transaction.jobDone());
	}
	
	@Test
	/* Normal case - with a few days passed - should return false */
	public void jobDoneFewDaysPassed()
	{
		ledger.nextDay();
		ledger.nextDay();
		assertFalse(transaction.jobDone());
	}
	
	@Test
	/* Normal case - exceed the days allocated - should return true */
	public void jobDoneExceeded()
	{
		//increment the day count by 7, so day is now 8
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		assertTrue(transaction.jobDone());
	}
	
	@Test
	/* Border case - last day - should return false */
	public void jobDoneLastDay()
	{
		//increment the day count by 6 so day is now 7 (on the edge of finishing)
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		assertFalse(transaction.jobDone());
	}
	
	
	@Test
	/* Normal case - check the stock level after selling 1 item */
	public void sellStockStockLevelOneItem() throws WarehouseException
	{
		int beforeSelling = ledger.inStock();
		transaction.sellStock(1);
		assertEquals(ledger.inStock(), new Integer(beforeSelling-1));
	}
	
	@Test
	/* Normal case - check the cash level after selling 1 item */
	public void sellStockCashLevelOneItem() throws WarehouseException
	{
		int beforeSelling = ledger.cashAvailable();
		transaction.sellStock(1);
		assertEquals(ledger.cashAvailable(), new Integer(beforeSelling + 8)); //8 is the wholesale price as constructed in @Before
	}
	
	@Test
	/* Normal case - check the day was incremented after selling 1 item */
	public void sellStockTurnedDayOneItem() throws WarehouseException
	{
		int beforeSelling = ledger.currentDay();
		transaction.sellStock(1);
		assertEquals(ledger.currentDay(), new Integer(beforeSelling + 1));
	}
	
	@Test(expected = Exception.class)
	/* Normal case - check an exception is thrown when items requested is negative */
	public void sellStockNegativeItems() throws WarehouseException
	{
		transaction.sellStock(-1);
	}
	
	@Test
	/* Border case - requested items input of 0. Checking the cash value. 
	 * (I assume this is allowed, since documentation only says exception on negatives */
	public void sellStockZeroItemsCash() throws WarehouseException
	{
		int beforeSelling = ledger.cashAvailable();
		transaction.sellStock(0);
		assertEquals(ledger.cashAvailable(), new Integer(beforeSelling + 0*8)); //8 is the wholesale price as constructed in @Before
	}
	
	@Test
	/* Border case - requested items input of 0. Checking the stock level. 
	 * (I assume this is allowed, since documentation only says exception on negatives */
	public void sellStockZeroItemsStock() throws WarehouseException
	{
		int beforeSelling = ledger.inStock();
		transaction.sellStock(0);
		assertEquals(ledger.inStock(), new Integer(beforeSelling-0));
	}
	
	@Test
	/* Border case - requested items input of 0. Checking the current day was incremented
	 * (I assume this is allowed, since documentation only says exception on negatives */
	public void sellStockZeroItemsDay() throws WarehouseException
	{
		int beforeSelling = ledger.currentDay();
		transaction.sellStock(0);
		assertEquals(ledger.currentDay(), new Integer(beforeSelling + 1));
	}
	
	
	
	@Test
	/* Normal case - check the stock level after selling 1 item. 
	 * The method should have restocked to capacity before selling items */
	public void restockAndsellStockCapacity() throws WarehouseException
	{
		transaction.sellStock(14); //remove some stock first, so we can test the restocking functionality
		transaction.restockAndSellStock(6);
		assertEquals(ledger.inStock(), new Integer(20 - 6));		
	}
	
	@Test
	/* Normal case - check the stock level when zero items requested */
	public void restockAndsellStockZeroItemsCapacity() throws WarehouseException
	{
		transaction.sellStock(14); //remove some stock first, so we can test the restocking functionality
		transaction.restockAndSellStock(0);
		assertEquals(ledger.inStock(), new Integer(20 - 0));		
	}
	
	@Test(expected = Exception.class)
	/* Border case - check the stock level when zero items requested */
	public void restockAndsellStockNegativeItemsCapacity() throws WarehouseException
	{
		transaction.sellStock(14); //remove some stock first, so we can test the restocking functionality
		transaction.restockAndSellStock(-1);	
	}
	
}
