package asgn1Solution;
import org.junit.*;
import static org.junit.Assert.*;

/**
 * @author Dominic Bou-Samra n6869378
 */

public class LedgerTest {
	
	private WarehouseLedger ledger;

	@Before
	public void setUp()
	{
		ledger = new WarehouseLedger(20, 80, 5, 8, 50);
		//capacity/initial stock = 20, initial cash = 80, wholesale per box = 5, 
		//retail per box = 8, delivery charge = 50
	}
	
	/* sellItems tests  */
	@Test
	/* Normal case - checking stock value after selling normal amount of items */ 
	public void sellItemsStockTest() throws WarehouseException
	{
		//checking before and after of inStock value
		int beforeSellingItems = ledger.inStock();
		ledger.sellItems(3);
		assertEquals(ledger.inStock(), new Integer(beforeSellingItems - 3));
	} 
	
	@Test
	/* Normal case - checking cash value after selling normal amount of items */
	public void sellItemsCashTest() throws WarehouseException
	{
		int beforeSellingItems = ledger.cashAvailable();
		ledger.sellItems(5);
		assertEquals(ledger.cashAvailable(), new Integer(beforeSellingItems + (5*8)));
	}
	
	@Test
	/* Normal case - checking number of items after selling more items then in stock */
	public void sellItemsMoreThenStock() throws WarehouseException
	{
		ledger.sellItems(ledger.inStock() + 1); //1 more item then currently in stock
		assertEquals(ledger.inStock(), new Integer(0));
	}
	
	@Test
	/* Normal case - checking cash level after selling more items then in stock */
	public void sellItemsMoreThenCashLevel() throws WarehouseException //terrible name I know
	{
		int beforeSellingItemsStockLevel = ledger.inStock();
		int beforeSellingItemsCashLevel = ledger.cashAvailable();
		ledger.sellItems(ledger.inStock() + 1);
		assertEquals(ledger.cashAvailable(), new Integer(beforeSellingItemsCashLevel + (8 * beforeSellingItemsStockLevel)));
	}
	
	@Test
	/* Normal case - checking return value after selling regular amount of items */
	public void sellItemsReturnValue() throws WarehouseException
	{
		assertTrue(ledger.sellItems(ledger.inStock() - 1));
	}
	
	@Test
	/* Normal case - checking return value after selling more items then in stock */
	public void sellItemsMoreThenReturnValue() throws WarehouseException
	{
		assertFalse(ledger.sellItems(ledger.inStock() + 1));
	}
	
	@Test
	/* Border case - selling zero items 
	 * I assume we can sell zero items, as the documentation only 
	 * explicitly forbids negative sell requests */
	public void sellItemsZeroItems() throws WarehouseException
	{
		int beforeSellingItems = ledger.cashAvailable();
		ledger.sellItems(0);
		assertEquals(ledger.cashAvailable(), new Integer(beforeSellingItems));
	}
	
	@Test(expected = Exception.class)
	/* Border case - selling negative items */
	public void sellItemsNegativeInput() throws WarehouseException
	{
		ledger.sellItems(-1);
	}
	

	/* buyItems tests  */
	
	@Test
	/* Normal case - checking stock value after buying items */ 
	public void buyItemsStockTest() throws WarehouseException
	{
		//checking before and after of inStock value
		int beforeBuyingItems = ledger.inStock();
		ledger.buyItems(3);
		assertEquals(ledger.inStock(), new Integer(beforeBuyingItems + 3));
	}
	
	@Test
	/* Typical test of normal values - checking cash available value */ 
	public void buyItemsCashTest() throws WarehouseException
	{
		int beforeBuyingItems = ledger.cashAvailable();
		ledger.buyItems(3);
		//delivery charge of 50, wholesale costs of 3 * 5
		assertEquals(ledger.cashAvailable(), new Integer(beforeBuyingItems - (3*5) - 50));
	}
	
	@Test
	/* Normal case - overdraw our budget by buying more then we can afford */
	public void buyItemsOverdrawBudget() throws WarehouseException
	{
		int beforeBuyingItemsCash = ledger.cashAvailable();
		
		//for the sake of pushing the cash reserve into negative values, I can use this method
		//however the restockAndSellStock method won't allow the buying of MORE then the warehouse can hold
		ledger.buyItems(30);
		
		assertEquals(ledger.cashAvailable(), new Integer(beforeBuyingItemsCash - (30*5) - 50)); //delivery charge of 50
	}
	
	@Test 
	/* Border case where order is 0 - checking cash available value.
	 * I wasn't sure if we should allow buying of 0 boxes of stock, 
	 * but I assumed yes, because the documentation only says exception 
	 * on negative values.*/
	public void buyZeroItemsCash() throws WarehouseException
	{
		int beforeBuyingItems = ledger.cashAvailable();
		ledger.buyItems(0);
		//delivery charge of 50
		assertEquals(ledger.cashAvailable(), new Integer(beforeBuyingItems - 50));
	}
	
	@Test
	/* Border case where order is 0 - checking stock available value */
	public void buyZeroItemsStock() throws WarehouseException
	{
		int beforeBuyingItems = ledger.inStock();
		ledger.buyItems(0);
		assertEquals(ledger.inStock(), new Integer(beforeBuyingItems));
	}
	
	
	@Test(expected = Exception.class)
	/* Extreme case - order is a negative value */
	public void buyNegativeItems() throws WarehouseException
	{
		ledger.buyItems(-1);
	}
	
	
	/* cashAvailable tests  */
	
	@Test
	/* Normal case - default value */
	public void cashAvailableDefaultValue()
	{
		assertEquals(ledger.cashAvailable(), new Integer(80));
	}
	
	@Test
	/* Normal case - selling items  */
	public void cashAvailableSelling() throws WarehouseException
	{
		ledger.sellItems(12);
		assertEquals(ledger.cashAvailable(), new Integer(80 + (8*12)));
	}
	
	@Test
	/* Normal case - buying items  */
	public void cashAvailableBuying() throws WarehouseException
	{
		ledger.buyItems(2);
		assertEquals(ledger.cashAvailable(), new Integer(80 - (2*5) - 50));
	}
	
	@Test
	/* Normal case - turning pages in ledger  */
	public void cashAvailablerNewDays() throws WarehouseException
	{
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		assertEquals(ledger.cashAvailable(5), new Integer(80));
	}
	
	@Test
	/* Normal case - selling items, and turning pages in ledger  */
	public void cashAvailableSellingNewDays() throws WarehouseException
	{
		//cash to begin with is 80
		ledger.sellItems(2);
		//cash after selling 2 items is 80 + 8*2
		ledger.nextDay();
		assertEquals(ledger.cashAvailable(2), new Integer(80 + (8*2)));
	}
	
	@Test
	/* Normal case - buying items, and turning pages in ledger */
	public void cashAvailableBuyingNewDays() throws WarehouseException
	{
		ledger.buyItems(2);
		ledger.nextDay();
		assertEquals(ledger.cashAvailable(2), new Integer(80 - (2*5) - 50));
	}
	
	@Test(expected = Exception.class)
	/* Border case - negative input (days less then 0) */
	public void cashAvailableNegativeDays() throws WarehouseException
	{
		ledger.cashAvailable(-6);
	}
	
	@Test(expected = Exception.class)
	/* Border case - input greater then current day  */
	public void cashAvailableTooManyDays() throws WarehouseException
	{
		int currentDay = ledger.currentDay();
		ledger.cashAvailable(currentDay + 6);
	}
	
	/* currentDay() Tests */
	
	@Test
	/* Normal case - default value */
	public void currentDayDefault()
	{
		assertEquals(ledger.currentDay(), new Integer(1));
	}
	
	@Test
	/* Normal case - go forward in time */
	public void currentDayPlusSome()
	{
		int startDay = ledger.currentDay();
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		assertEquals(ledger.currentDay(), new Integer(startDay + 3));
	}

	@Test
	/* Normal case - default starting value */
	public void inStockDefault()
	{
		assertEquals(ledger.inStock(), new Integer(20));
	}
	
	@Test
	/* Normal case - sold some stock  */
	public void inStockSoldSome() throws WarehouseException
	{
		int inStockBeginning = ledger.inStock();
		ledger.sellItems(3);
		assertEquals(ledger.inStock(), new Integer(inStockBeginning - 3));
	}
	
	@Test
	/* Normal case - bought some stock  */
	public void inStockBoughtSome() throws WarehouseException
	{
		ledger.sellItems(6);
		int inStockBeginning = ledger.inStock();
		ledger.buyItems(4);
		assertEquals(ledger.inStock(), new Integer(inStockBeginning + 4));
	}
	
	@Test
	/* Normal case - go forward in time, and check prior days stock level */
	public void inStockPriorDaysStock() throws WarehouseException
	{
		int inStockBeginning = ledger.inStock();
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		ledger.sellItems(5);
		assertEquals(ledger.inStock(1), new Integer(inStockBeginning));
	}
	
	@Test
	/* Normal case - current stock level with day parameter as current day  */
	public void inStockOnCurrentDay() throws WarehouseException
	{
		int inStockBeginning = ledger.inStock();
		ledger.nextDay();
		ledger.nextDay();
		ledger.nextDay();
		ledger.sellItems(5);
		assertEquals(ledger.inStock(4), new Integer(inStockBeginning-5));
	}
	
	@Test(expected = Exception.class)
	/* Extreme case - day is greater then current day (i.e. in the future) */
	public void inStockFutureInput() throws WarehouseException
	{
		ledger.inStock(ledger.currentDay() + 1);
	}
	
	@Test(expected = Exception.class)
	/* Extreme case - day is negative */
	public void inStockNegativeInput() throws WarehouseException
	{
		ledger.inStock(-1);
	}
	
	@Test(expected = Exception.class)
	/* Extreme case - if the day is less then 1, but not negative - zero */
	public void inStockZeroInput() throws WarehouseException
	{
		ledger.inStock(0);
	}
	
	@Test
	/* Normal case - expected output for default values */
	public void toStringNormalInputs()
	{
		assertEquals(ledger.toString(), "Day 1: Cash reserve = $80; Items in stock = 20\n");
	}
	
	
	
}
